﻿using System;
using ServiceNow;
using ServiceNow.Interface;
using ServiceNow.TableAPI;
using ServiceNow.TableDefinitions;
using System.Configuration;
using System.Linq;
using System.Collections.Generic;

namespace UsageDemo
{
    class Program
    {
        //static string myInstance = "dev10541";
        //static string instanceUserName = "Admin";
        //static string instancePassword = "WKY6gRr4fyUh";

        static void Main(string[] args)
        {
            // Shows basic CRUD operations with a simple small subset of a record
            // basicOperations();

            // Demonstrates a more advanced retrieval including related resource by link and dot traversal.
            // retrieveByQuery();

            //create an incident

            // CreateanIncident();

             var res=   retrieveIncidentsByQuery();
            // CreateanIncident1();
            // Break
            Console.WriteLine("\n\rCompleted.");
            Console.ReadLine();
        }

        static void basicOperations()
        {
            var myInstance = ConfigurationManager.AppSettings["ServiceNowInstance"];
            var instanceUserName = ConfigurationManager.AppSettings["ServiceNowInstanceUSerName"];
            var instancePassword = ConfigurationManager.AppSettings["ServiceNowInstancePassword"];
            TableAPIClient<sys_user> userClient = new TableAPIClient<sys_user>("sys_user", myInstance, instanceUserName, instancePassword);

            // Deomstrate the Create (POST) operation:
            var createdUser = userClient.Post(new sys_user()
            {
                employee_number = "012345",
                first_name = "Tester",
                last_name = "McTester",
                email = "tester@testcompany.com",
                phone = "",
                // You can use Name instead of sys_id, but if service now does not find your value it will ignore it without any warning.
                location = new ResourceLink() { value = "VISALIA COURTHOUSE" }  
            });
            Console.WriteLine("User Created: " + createdUser.Result.first_name + " " + createdUser.Result.last_name + " (" + createdUser.Result.sys_id + ")");


            // Deonstrate the GetById (GET) operation:
            var retrievedUser = userClient.GetById(createdUser.Result.sys_id);
            Console.WriteLine("User Retrieved: " + retrievedUser.Result.first_name + " " + retrievedUser.Result.last_name + " (" + retrievedUser.Result.sys_id + ")");
            Console.WriteLine("              : eMail: " + retrievedUser.Result.email);
            Console.WriteLine("              : Location: " + retrievedUser.Result.Location_name);


            // Demonstrate Update (PUT) operation:
            Console.WriteLine("\n\nUpdating User");
            if (retrievedUser.Result != null)
            {
                var d = retrievedUser.Result;
                d.email = "newEmail@testcompany.com";

                // Set the location using the Guid of a good location, otherwise handle it.
                try
                {                    
                   // d.location = new ResourceLink() { value = findLocationId("10369 Democracy Lane, Fairfax,VA") };
                }
                catch(Exception ex)
                {
                    Console.WriteLine("Unable to set new user location: " + ex.Message);
                }

                var updatedUser = userClient.Put(d);
                Console.WriteLine("              : eMail: " + updatedUser.Result.email);
                Console.WriteLine("              : Location: " + updatedUser.Result.Location_name);
            }


            // Domonstrate Delete operation
            Console.Write("\n\nDeleting User");            
            userClient.Delete(retrievedUser.Result.sys_id);
            Console.WriteLine("...Done");
        }
        

        static List<incident> retrieveIncidentsByQuery()
        {
           // Console.WriteLine("\n\nRetrieving active, unresolved incidents");
            var myInstance = ConfigurationManager.AppSettings["ServiceNowInstance"];
            var instanceUserName = ConfigurationManager.AppSettings["ServiceNowInstanceUSerName"];
            var instancePassword = ConfigurationManager.AppSettings["ServiceNowInstancePassword"];
          //  var query = @"active=true^u_resolved=false";
            var query = ConfigurationManager.AppSettings["ServiceNowOpenIncidentQuery"];
           // query = query.Replace("{0}", "Rick Berzle");
            TableAPIClient<incident> client = new TableAPIClient<incident>("incident", myInstance, instanceUserName, instancePassword);

            IRestQueryResponse<incident> response = client.GetByQuery(query);

            //Console.WriteLine(response.ResultCount + " records found. \n\nPress return to list results.");
            //Console.ReadLine();
            foreach (incident r in response.Result.Where(x=>x.caller_id.value=="Nanda"))
            {
                DateTime openedOn = DateTime.Parse(r.opened_at);
                ResourceLink openedFor = r.caller_id;

             //   Console.WriteLine(r.number + " :  " + r.short_description + " (Opened " + openedOn.ToShortDateString() + " for " + r.caller_first_name + ")");
            }
            return response.Result.ToList<incident>();

        }

        static void CreateanIncident1()
        {
            incident inc = new incident();
            inc.active = true;
            inc.caller_first_name = "Nanda";
            inc.caller_id = new ResourceLink() { link = "www.google.com", value = "Nanda" };
            inc.caller_last_name = "Hiremath";
            inc.caller_location_latitude = "Bangalore";
            inc.caller_location_name = "Bangalore";
            inc.description = "AC not working";
            inc.short_description = "AC not working";
            inc.incident_state = "1";

           // inc.number = "1000";
            inc.opened_by = new ResourceLink() { link = "www.google.com", value = "Nanda" };
            inc.opened_at = "Bangalore";

            CreateanIncident(inc);
        }
        static incident CreateanIncident(incident inc)
        {
           // Console.WriteLine("\n\n creating a ticket");
            //var query = @"active=true^u_resolved=false";
            var myInstance = ConfigurationManager.AppSettings["ServiceNowInstance"];
            var instanceUserName = ConfigurationManager.AppSettings["ServiceNowInstanceUSerName"];
            var instancePassword = ConfigurationManager.AppSettings["ServiceNowInstancePassword"];
            TableAPIClient<incident> client = new TableAPIClient<incident>("incident", myInstance, instanceUserName, instancePassword);


            RESTSingleResponse<incident> response = client.Post(inc);

            //  Console.WriteLine(response.ResultCount + " records found. \n\nPress return to list results.");
            //  Console.ReadLine();
            return response.Result;
        }

        public void DeleteIncident(string incidentId)
        {
           // Console.WriteLine("\n\n deleting a ticket");
            //var query = @"active=true^u_resolved=false";
            var myInstance = ConfigurationManager.AppSettings["ServiceNowInstance"];
            var instanceUserName = ConfigurationManager.AppSettings["ServiceNowInstanceUSerName"];
            var instancePassword = ConfigurationManager.AppSettings["ServiceNowInstancePassword"];
            TableAPIClient<incident> client = new TableAPIClient<incident>("incident", myInstance, instanceUserName, instancePassword);

             client.Delete(incidentId);

           // Console.WriteLine(response.ResultCount + " records found. \n\nPress return to list results.");
          //  Console.ReadLine();
        }

        public incident UpdateIncident(incident inc)
        {
           // Console.WriteLine("\n\n creating a ticket");
            var myInstance = ConfigurationManager.AppSettings["ServiceNowInstance"];
            var instanceUserName = ConfigurationManager.AppSettings["ServiceNowInstanceUSerName"];
            var instancePassword = ConfigurationManager.AppSettings["ServiceNowInstancePassword"];
            //var query = @"active=true^u_resolved=false";
            TableAPIClient<incident> client = new TableAPIClient<incident>("incident", myInstance, instanceUserName, instancePassword);

            // sis_id is important
            RESTSingleResponse<incident> response = client.Put(inc);

            //  Console.WriteLine(response.ResultCount + " records found. \n\nPress return to list results.");
            //  Console.ReadLine();
            return response.Result;
        }
        // You would of course have these cached somewhere most likely.
        public string findLocationId(string locationName)
        {
            var myInstance = ConfigurationManager.AppSettings["ServiceNowInstance"];
            var instanceUserName = ConfigurationManager.AppSettings["ServiceNowInstanceUSerName"];
            var instancePassword = ConfigurationManager.AppSettings["ServiceNowInstancePassword"];
            TableAPIClient<location> locationClient = new TableAPIClient<location>("cmn_location", myInstance, instanceUserName, instancePassword);
            var query = @"name=" + locationName;

            IRestQueryResponse<location> locationResult = locationClient.GetByQuery(query);
            if (locationResult.ResultCount == 0) throw new Exception(String.Format("No location by the name {0} was found.", locationName));
            if (locationResult.ResultCount > 1) throw new Exception(String.Format("Multiple locations found by the name {0}.", locationName));

            // We found our location lets return it
            return locationResult.Result.First().sys_id;
        }
    }
}
