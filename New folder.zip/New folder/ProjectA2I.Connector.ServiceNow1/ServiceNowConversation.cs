﻿using ProjectA2I.Conversation.Builder;
using ProjectA2I.Conversation.Builder.Conversations;
using ProjectA2I.Conversation.Builder.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Configuration;
using ServiceNow;
using ServiceNow.Interface;
using ServiceNow.TableAPI;
using ServiceNow.TableDefinitions;

namespace ProjectA2I.Connector.ServiceNow1
{
    public class ServiceNowConversation
    {
        [BotIntent("CreateTicket")]
        public async Task<IMessageActivity> CreateTicket(IConversationContext context, IAwaitable<IMessageActivity> message, BotResult result)
        {
            var postedMessage = await message;
            bool didfind = false;

            #region CreateTicket

            var responsedicitionary = ((Dictionary<string, object>)result.Entities);

            incident inc = new incident();
            
            inc.active = true;
            inc.caller_first_name = responsedicitionary["caller_first_name"].ToString();
            inc.caller_id = new ResourceLink() { link = responsedicitionary["caller_id_link"].ToString(), value = responsedicitionary["caller_id"].ToString() };
            inc.caller_last_name = responsedicitionary["caller_last_name"].ToString(); ;
            inc.caller_location_latitude = responsedicitionary["caller_location_latitude"].ToString(); ;
            inc.caller_location_name = responsedicitionary["caller_location_name"].ToString(); ;
            inc.description = responsedicitionary["description"].ToString(); ;
            inc.short_description = responsedicitionary["short_description"].ToString();

           // inc.number = responsedicitionary[""].ToString(); ;
            inc.opened_by = new ResourceLink() { link = responsedicitionary["opened_by"].ToString(), value = responsedicitionary["opened_by"].ToString()   };
            inc.opened_at = DateTime.Now.ToString(); 
            try
            {
              var reult=  CreateanIncident(inc);
            }
            catch (Exception ex)
            {
                throw;
            }
            Activity activity = new Activity();
           
                activity.Text = "TIcket has ben raised successfully..!!";
            
            return activity;

            #endregion
        }

        [BotIntent("RetrieveTicketDetails")]
        public async Task<IMessageActivity> RetrieveTicketDetails(IConversationContext context, IAwaitable<IMessageActivity> message, BotResult result)
        {
            var postedMessage = await message;
           // bool didfind = false;

            #region RetrieveTicketDetails

            var responsedicitionary = ((Dictionary<string, object>)result.Entities);

            var shortdesc= responsedicitionary["short_description"].ToString();
            var callerid = responsedicitionary["caller_id"].ToString();
            try
            {
                retrieveIncidentsByQuery(callerid, shortdesc);
            }
            catch (Exception ex)
            {
                throw;
            }
            Activity activity = new Activity();
           
                activity.Text = " ";
           
            return activity;

            #endregion
        }

        public List<incident> retrieveIncidentsByQuery(string callerid,string shortdesc)
        {
            // Console.WriteLine("\n\nRetrieving active, unresolved incidents");
            var myInstance = ConfigurationManager.AppSettings["ServiceNowInstance"];
            var instanceUserName = ConfigurationManager.AppSettings["ServiceNowInstanceUSerName"];
            var instancePassword = ConfigurationManager.AppSettings["ServiceNowInstancePassword"];
            //  var query = @"active=true^u_resolved=false";
            var query = ConfigurationManager.AppSettings["ServiceNowOpenIncidentQuery"];
            TableAPIClient<incident> client = new TableAPIClient<incident>("incident", myInstance, instanceUserName, instancePassword);

            IRestQueryResponse<incident> response = client.GetByQuery(query);

            //Console.WriteLine(response.ResultCount + " records found. \n\nPress return to list results.");
            //Console.ReadLine();
            foreach (incident r in response.Result.Where(x => x.caller_id.value == callerid && x.short_description.Contains(shortdesc)))
            {
                DateTime openedOn = DateTime.Parse(r.opened_at);
                ResourceLink openedFor = r.caller_id;

                //   Console.WriteLine(r.number + " :  " + r.short_description + " (Opened " + openedOn.ToShortDateString() + " for " + r.caller_first_name + ")");
            }
            return response.Result.ToList<incident>();

        }

        public incident CreateanIncident(incident inc)
        {
            // Console.WriteLine("\n\n creating a ticket");
            //var query = @"active=true^u_resolved=false";
            var myInstance = ConfigurationManager.AppSettings["ServiceNowInstance"];
            var instanceUserName = ConfigurationManager.AppSettings["ServiceNowInstanceUSerName"];
            var instancePassword = ConfigurationManager.AppSettings["ServiceNowInstancePassword"];
            TableAPIClient<incident> client = new TableAPIClient<incident>("incident", myInstance, instanceUserName, instancePassword);


            RESTSingleResponse<incident> response = client.Post(inc);

            //  Console.WriteLine(response.ResultCount + " records found. \n\nPress return to list results.");
            //  Console.ReadLine();
            return response.Result;
        }

       
    }
}
